Programa para encriptar senhas no formato sha256.
1 - Edite o arquivo "senhas.txt" com uma senha por linha. As senhas podem ser do formato que desejar, devem apenas ser inseridas uma por linha.
2 - Construa e execute o arquivo "encriptar.cpp". (ex.: g++ encriptar.cpp sha256.cpp -o main).
3 - As senhas criptografadas estar�o no arquivo "senhasEncriptadas.txt" na mesma ordem em que foram armazenadas em "senhas.txt".
4 - Para uso no trabalho distribua as senhas encriptadas de acordo com seu gosto no arquivo "logins.csv".